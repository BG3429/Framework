var class_ubiquity_1_1controllers_1_1_controller_base =
[
    [ "finalize", "class_ubiquity_1_1controllers_1_1_controller_base.html#a9caaa1f5ea6177e55f13ebe7dec2bd60", null ],
    [ "initialize", "class_ubiquity_1_1controllers_1_1_controller_base.html#a91098fa7d1917ce4833f284bbef12627", null ],
    [ "$footerView", "class_ubiquity_1_1controllers_1_1_controller_base.html#a7d59ef00bfa6b634199366afd577422d", null ],
    [ "$headerView", "class_ubiquity_1_1controllers_1_1_controller_base.html#a0e1e4d54bf985b5aab89204dd3f0f38d", null ]
];