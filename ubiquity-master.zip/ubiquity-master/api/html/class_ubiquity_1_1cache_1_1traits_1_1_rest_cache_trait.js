var class_ubiquity_1_1cache_1_1traits_1_1_rest_cache_trait =
[
    [ "getRestCache", "class_ubiquity_1_1cache_1_1traits_1_1_rest_cache_trait.html#af7e268f6f4beed52b4c0e5ebe044a0c8", null ],
    [ "getRestCacheController", "class_ubiquity_1_1cache_1_1traits_1_1_rest_cache_trait.html#a8172c338c31e45d40f6b9aa8d4f237f7", null ],
    [ "getRestResource", "class_ubiquity_1_1cache_1_1traits_1_1_rest_cache_trait.html#a4aa143cf73ab1a79670466538509fdb3", null ],
    [ "getRestRoutes", "class_ubiquity_1_1cache_1_1traits_1_1_rest_cache_trait.html#aa04e4bc9794861e4805c93ba3d31512a", null ],
    [ "initRestCache", "class_ubiquity_1_1cache_1_1traits_1_1_rest_cache_trait.html#a76dc970533d600ca466bbe5f2690c3bd", null ]
];