var class_ubiquity_1_1annotations_1_1_yuml_annotation =
[
    [ "$color", "class_ubiquity_1_1annotations_1_1_yuml_annotation.html#aac3430cb9e46a0a966f9e52fb5b0f2e5", null ],
    [ "$note", "class_ubiquity_1_1annotations_1_1_yuml_annotation.html#a94fd1dcedc1bbef06b8a9fd0086526b3", null ]
];