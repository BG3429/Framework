var class_ubiquity_1_1annotations_1_1router_1_1_route_annotation =
[
    [ "initAnnotation", "class_ubiquity_1_1annotations_1_1router_1_1_route_annotation.html#a33d4564dcd62c7891955cf6f83e06e34", null ],
    [ "$automated", "class_ubiquity_1_1annotations_1_1router_1_1_route_annotation.html#af862a7cfea6a55df8e5816f94d822754", null ],
    [ "$cache", "class_ubiquity_1_1annotations_1_1router_1_1_route_annotation.html#ac2dc76d756ec398393d4b1d23659276c", null ],
    [ "$duration", "class_ubiquity_1_1annotations_1_1router_1_1_route_annotation.html#acae43950182b63cd06434397298dad7d", null ],
    [ "$inherited", "class_ubiquity_1_1annotations_1_1router_1_1_route_annotation.html#a943fb255b4b12747347f2b3aae6f72ce", null ],
    [ "$methods", "class_ubiquity_1_1annotations_1_1router_1_1_route_annotation.html#a802753499268a04da139bd6e6ef89b35", null ],
    [ "$name", "class_ubiquity_1_1annotations_1_1router_1_1_route_annotation.html#ab2fc40d43824ea3e1ce5d86dee0d763b", null ],
    [ "$path", "class_ubiquity_1_1annotations_1_1router_1_1_route_annotation.html#a0a4baf0b22973c07685c3981f0d17fc4", null ],
    [ "$requirements", "class_ubiquity_1_1annotations_1_1router_1_1_route_annotation.html#a244d94e62cffe97e11aa1633b809dfa1", null ]
];