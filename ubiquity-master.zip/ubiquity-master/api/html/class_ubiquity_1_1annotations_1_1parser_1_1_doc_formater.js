var class_ubiquity_1_1annotations_1_1parser_1_1_doc_formater =
[
    [ "__construct", "class_ubiquity_1_1annotations_1_1parser_1_1_doc_formater.html#a095c5d389db211932136b53f25f39685", null ],
    [ "_replaceAll", "class_ubiquity_1_1annotations_1_1parser_1_1_doc_formater.html#a9fe46b1bf3fac957578d65b7549a5556", null ],
    [ "getReplacement", "class_ubiquity_1_1annotations_1_1parser_1_1_doc_formater.html#a05da72a1497f723a891d69a4f09ce5d3", null ],
    [ "getTypesRegex", "class_ubiquity_1_1annotations_1_1parser_1_1_doc_formater.html#abb2b0e4498d3ea07df8aab05baeda4da", null ],
    [ "getVariablesRegex", "class_ubiquity_1_1annotations_1_1parser_1_1_doc_formater.html#ae02d734d369ddc61cb23b707678933de", null ],
    [ "replaceAll", "class_ubiquity_1_1annotations_1_1parser_1_1_doc_formater.html#ae4a14850741219f1a218ae9486302061", null ],
    [ "replaceTypes", "class_ubiquity_1_1annotations_1_1parser_1_1_doc_formater.html#a0130795eddeef2f9a35c55853722f979", null ],
    [ "replaceVariables", "class_ubiquity_1_1annotations_1_1parser_1_1_doc_formater.html#a9a366241d1e70588654a4368ecbcc972", null ],
    [ "$replacements", "class_ubiquity_1_1annotations_1_1parser_1_1_doc_formater.html#a93cb3f67ace379a71de4fb00bcc7a605", null ],
    [ "$types", "class_ubiquity_1_1annotations_1_1parser_1_1_doc_formater.html#a92d70a97331cc6fc0a79d9da50895be8", null ],
    [ "variables", "class_ubiquity_1_1annotations_1_1parser_1_1_doc_formater.html#a626e63c7be6e71872233832cce1dccc0", null ]
];