var class_ubiquity_1_1annotations_1_1rest_1_1_rest_annotation =
[
    [ "$resource", "class_ubiquity_1_1annotations_1_1rest_1_1_rest_annotation.html#abd4c7b8b084214b8d2533ba07fce6b83", null ]
];