var class_ubiquity_1_1cache_1_1parser_1_1_rest_controller_parser =
[
    [ "__construct", "class_ubiquity_1_1cache_1_1parser_1_1_rest_controller_parser.html#a095c5d389db211932136b53f25f39685", null ],
    [ "_getResourceName", "class_ubiquity_1_1cache_1_1parser_1_1_rest_controller_parser.html#a4e2dcf726a03633c1c74d0fe03755c46", null ],
    [ "asArray", "class_ubiquity_1_1cache_1_1parser_1_1_rest_controller_parser.html#a12b8efb717cb31322bfa4d1d75146979", null ],
    [ "isRest", "class_ubiquity_1_1cache_1_1parser_1_1_rest_controller_parser.html#acd385c67829effd7f9c6dca817c7fc40", null ],
    [ "parse", "class_ubiquity_1_1cache_1_1parser_1_1_rest_controller_parser.html#affc9fadc8ae8e44f6d7002a423a64cfc", null ],
    [ "$authorizationMethods", "class_ubiquity_1_1cache_1_1parser_1_1_rest_controller_parser.html#afee45e653f52aaaba8b6d7665f3ef83b", null ],
    [ "$controllerClass", "class_ubiquity_1_1cache_1_1parser_1_1_rest_controller_parser.html#ae59cce8aa29e170d0f225cea7d0a14fd", null ],
    [ "$resource", "class_ubiquity_1_1cache_1_1parser_1_1_rest_controller_parser.html#abd4c7b8b084214b8d2533ba07fce6b83", null ],
    [ "$rest", "class_ubiquity_1_1cache_1_1parser_1_1_rest_controller_parser.html#ae9b43b08b84a4aa4a64f85c04c876e61", null ],
    [ "$route", "class_ubiquity_1_1cache_1_1parser_1_1_rest_controller_parser.html#af4105acdee5d34dc96c2aec4058b81f9", null ]
];