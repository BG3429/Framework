var class_ubiquity_1_1annotations_1_1_one_to_many_annotation =
[
    [ "$className", "class_ubiquity_1_1annotations_1_1_one_to_many_annotation.html#acd6a475a6eeb092f4eea3e19e502d67d", null ],
    [ "$fetch", "class_ubiquity_1_1annotations_1_1_one_to_many_annotation.html#a94ed3b2f8cc7709070362b3362af35ac", null ],
    [ "$mappedBy", "class_ubiquity_1_1annotations_1_1_one_to_many_annotation.html#a1c4bf934691a992fa08cdcb67ed7a945", null ]
];