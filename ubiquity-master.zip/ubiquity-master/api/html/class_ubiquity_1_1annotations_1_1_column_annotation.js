var class_ubiquity_1_1annotations_1_1_column_annotation =
[
    [ "$dbType", "class_ubiquity_1_1annotations_1_1_column_annotation.html#a63b68daf124fa00e6bcfce64fabbdbe1", null ],
    [ "$name", "class_ubiquity_1_1annotations_1_1_column_annotation.html#ab2fc40d43824ea3e1ce5d86dee0d763b", null ],
    [ "$nullable", "class_ubiquity_1_1annotations_1_1_column_annotation.html#a57b7073e8bc5ba81fb71b49080cbaea6", null ]
];