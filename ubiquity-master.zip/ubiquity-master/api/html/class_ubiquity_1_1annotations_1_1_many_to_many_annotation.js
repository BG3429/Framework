var class_ubiquity_1_1annotations_1_1_many_to_many_annotation =
[
    [ "$inversedBy", "class_ubiquity_1_1annotations_1_1_many_to_many_annotation.html#affdd9d27a393d5b0e4a5efc03d488ea5", null ],
    [ "$mappedBy", "class_ubiquity_1_1annotations_1_1_many_to_many_annotation.html#a1c4bf934691a992fa08cdcb67ed7a945", null ],
    [ "$targetEntity", "class_ubiquity_1_1annotations_1_1_many_to_many_annotation.html#afa99fba34d71439e1f94d883b4663efb", null ]
];