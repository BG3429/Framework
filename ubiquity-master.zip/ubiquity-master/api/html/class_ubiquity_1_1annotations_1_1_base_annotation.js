var class_ubiquity_1_1annotations_1_1_base_annotation =
[
    [ "__toString", "class_ubiquity_1_1annotations_1_1_base_annotation.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ],
    [ "asPhpArray", "class_ubiquity_1_1annotations_1_1_base_annotation.html#af9fd0237c27cd114088e4dcf76ef5616", null ],
    [ "getProperties", "class_ubiquity_1_1annotations_1_1_base_annotation.html#ad92c14b6c86304d3f1fb86b2936d3408", null ],
    [ "getPropertiesAndValues", "class_ubiquity_1_1annotations_1_1_base_annotation.html#a448b36649ab596b17451aed9e30b072f", null ]
];