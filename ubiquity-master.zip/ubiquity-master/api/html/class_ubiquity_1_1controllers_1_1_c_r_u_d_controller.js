var class_ubiquity_1_1controllers_1_1_c_r_u_d_controller =
[
    [ "index", "class_ubiquity_1_1controllers_1_1_c_r_u_d_controller.html#a149eb92716c1084a935e04a8d95f7347", null ],
    [ "$model", "class_ubiquity_1_1controllers_1_1_c_r_u_d_controller.html#a08fdd91bde255dbe3e2d15a22d9663e8", null ],
    [ "$views", "class_ubiquity_1_1controllers_1_1_c_r_u_d_controller.html#a2bc32a57c3a42b3b411c76e457481767", null ]
];