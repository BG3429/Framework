var class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait =
[
    [ "_getFiles", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#ab44b4efeb789f43d947c9016181e4654", null ],
    [ "addAdminRoutes", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#aef1e3f6ab59f029b42c73065987cc60f", null ],
    [ "addControllerCache", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#a0f778cd649ae02167a282881c24f5fdd", null ],
    [ "addRoute", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#add52b672dacee8822f085cbe9b65d7d6", null ],
    [ "expired", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#a2c1127a01a222557ddc0c0225fd7c5c1", null ],
    [ "getControllerCache", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#a1b76cf2460c5596848726839850ec375", null ],
    [ "getControllerRoutes", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#a6fad84358d8ca93d34cda1f29dd56a40", null ],
    [ "getControllers", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#af91595b2fdb4297bfb468368de301735", null ],
    [ "getControllersFiles", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#a353a7d4f94388ecb60d535fcb38ce7c2", null ],
    [ "getRouteCache", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#a64a9014e5f5c777b6fa394d8cc8319d4", null ],
    [ "getRouteKey", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#af93ed880557422282a08cc744e6c1dbc", null ],
    [ "getRoutes", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#a5ee75c365fa519c6bf61c9ae28672a7d", null ],
    [ "initRouterCache", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#a0325c1dfb46fbe26208f6abab558396a", null ],
    [ "isExpired", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#ab825874bfd17c14ec7c181ca7157ffd5", null ],
    [ "setExpired", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#aa4209f435cd8c41a6cd5c16e9289f48d", null ],
    [ "setKeyExpired", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#ab9a55351f7e37d3f768b7a9670e1cc2a", null ],
    [ "setRouteCache", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#a518ddd58c101eb404dc800d1d3ad9510", null ],
    [ "storeRouteResponse", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#a90633aff7ba9f5e89368db85ad6ae632", null ],
    [ "$expiredRoutes", "class_ubiquity_1_1cache_1_1traits_1_1_router_cache_trait.html#aeaebf5067b8fc73a192f43e6311e542b", null ]
];