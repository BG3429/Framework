var class_ubiquity_1_1cache_1_1system_1_1_apcu_cache =
[
    [ "__construct", "class_ubiquity_1_1cache_1_1system_1_1_apcu_cache.html#a2357b71045b70da97ba62b9aa295d777", null ],
    [ "clear", "class_ubiquity_1_1cache_1_1system_1_1_apcu_cache.html#aa821bec12eaa7e0f649397c9675ff505", null ],
    [ "clearCache", "class_ubiquity_1_1cache_1_1system_1_1_apcu_cache.html#a8c49e010e3a98b168f52105500947572", null ],
    [ "exists", "class_ubiquity_1_1cache_1_1system_1_1_apcu_cache.html#ace1ae5be37bf26c172cc7ea4e1a65e26", null ],
    [ "fetch", "class_ubiquity_1_1cache_1_1system_1_1_apcu_cache.html#a968e57d6786a8c6cadfa52951a9ed768", null ],
    [ "file_get_contents", "class_ubiquity_1_1cache_1_1system_1_1_apcu_cache.html#a0d104de0ffa0a4ab9132923a03144099", null ],
    [ "getAllEntries", "class_ubiquity_1_1cache_1_1system_1_1_apcu_cache.html#abaf756f1c91682bfb0006e6d0b83deb0", null ],
    [ "getCacheEntries", "class_ubiquity_1_1cache_1_1system_1_1_apcu_cache.html#a068be8417611f960a52d47582ee99291", null ],
    [ "getCacheFiles", "class_ubiquity_1_1cache_1_1system_1_1_apcu_cache.html#a642a63febaf1cd512555a3bdec5b2411", null ],
    [ "getEntryKey", "class_ubiquity_1_1cache_1_1system_1_1_apcu_cache.html#ac97e94d37deeb951293028c85dbfb0db", null ],
    [ "getRealKey", "class_ubiquity_1_1cache_1_1system_1_1_apcu_cache.html#a68ea5fc5b5b6c1052442726fe76c8cf8", null ],
    [ "getTimestamp", "class_ubiquity_1_1cache_1_1system_1_1_apcu_cache.html#aff0cbcd61bb5f05632e20fd0baf65714", null ],
    [ "remove", "class_ubiquity_1_1cache_1_1system_1_1_apcu_cache.html#a95483af4e2c07dc9893fe058b026bd5d", null ],
    [ "store", "class_ubiquity_1_1cache_1_1system_1_1_apcu_cache.html#abb4d1a5e6e951eb533da34f8395d1e87", null ],
    [ "storeContent", "class_ubiquity_1_1cache_1_1system_1_1_apcu_cache.html#a92ecbb1a81e82f7397b6016128b594c6", null ]
];