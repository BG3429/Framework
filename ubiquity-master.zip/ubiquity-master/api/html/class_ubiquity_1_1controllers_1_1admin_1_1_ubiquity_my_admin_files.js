var class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files =
[
    [ "getAdminBaseRoute", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#a0a2021eb345af5198d4ee310a5ad531a", null ],
    [ "getViewCacheIndex", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#a3c4561d6ecfdf860860f3b93430b2964", null ],
    [ "getViewClassesDiagram", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#a6ef84839e36a75d1fc03dc88b192e909", null ],
    [ "getViewConfigIndex", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#a1b4389fddb52fb01945b60c47ee0904f", null ],
    [ "getViewControllersIndex", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#aa836b345a161b1e9f8b754df135d1d47", null ],
    [ "getViewDatabaseCreate", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#a5b8584e80185b4c229df01b51d3574b3", null ],
    [ "getViewDatabaseIndex", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#a9ab9622127f7399aeee88e4ee987f3c2", null ],
    [ "getViewDataIndex", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#ac844e63cf525cbee68bf0587a74502d7", null ],
    [ "getViewDatasExport", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#ae7fa9840edf6980a26b47e4348f161b1", null ],
    [ "getViewEditTable", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#aebb343fa32e9b53e6e2c1837c4406501", null ],
    [ "getViewHeader", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#abd3b5184b9efa5c5f933a34ba4197cde", null ],
    [ "getViewIndex", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#a0c4b4aaf46d1e264775d02f4ef0be1ba", null ],
    [ "getViewLogsIndex", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#a0bdcd298373b6b95ccc3dcdfef62e8c5", null ],
    [ "getViewRestFormTester", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#a33a2dd35b1c01fc76e954d1541fcb106", null ],
    [ "getViewRestIndex", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#a2c0efebcb28913f65aa7355f735a9cc3", null ],
    [ "getViewRoutesIndex", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#af70c9e319fb6946bad43c327af78e2cc", null ],
    [ "getViewSeoDetails", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#aaf2c7aa6a30a9ba9a6841a15f589cc86", null ],
    [ "getViewSeoIndex", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#aefdd149a8e24fa73457ec3020819585f", null ],
    [ "getViewShowTable", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#a14b65a22ff6e36c1bd16ebb089db691f", null ],
    [ "getViewYumlReverse", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_files.html#a6834b84d0e8557b129b8aebc7b47a03f", null ]
];