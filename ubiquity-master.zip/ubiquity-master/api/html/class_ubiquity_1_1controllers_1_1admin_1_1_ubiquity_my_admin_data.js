var class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_data =
[
    [ "getFieldNames", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_data.html#aad7dfd1ff04fe04ad477157f9fe9073a", null ],
    [ "getFormFieldNames", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_data.html#afe07a0ce9f486d3186ebadd9462623bc", null ],
    [ "getManyToManyDatas", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_data.html#a5e067feff4abdabedf5a57038a2f0b4f", null ],
    [ "getTableNames", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_data.html#a31fd028456fa69d0f2abe63ffd4054a9", null ],
    [ "getUpdateManyToManyInForm", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_data.html#a404c7762f28bc1f350f5782d381822c8", null ],
    [ "getUpdateManyToOneInForm", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_data.html#a433f98ec0d5088d33585edafbd63e615", null ],
    [ "getUpdateOneToManyInForm", "class_ubiquity_1_1controllers_1_1admin_1_1_ubiquity_my_admin_data.html#a75c77feef89350a7338ae8cbdd33c919", null ]
];