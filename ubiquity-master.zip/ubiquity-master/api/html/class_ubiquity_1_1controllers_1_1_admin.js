var class_ubiquity_1_1controllers_1_1_admin =
[
    [ "index", "class_ubiquity_1_1controllers_1_1_admin.html#a149eb92716c1084a935e04a8d95f7347", null ],
    [ "opCacheReset", "class_ubiquity_1_1controllers_1_1_admin.html#a638452c199ebd3990315b71854ad9283", null ]
];