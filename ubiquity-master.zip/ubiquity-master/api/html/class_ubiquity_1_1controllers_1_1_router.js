var class_ubiquity_1_1controllers_1_1_router =
[
    [ "_getURL", "class_ubiquity_1_1controllers_1_1_router.html#a212ed5ead9041c60e628e613657ea8dc", null ],
    [ "addRoute", "class_ubiquity_1_1controllers_1_1_router.html#ac96535fecece764ca9447209840e7f57", null ],
    [ "addRouteToRoutes", "class_ubiquity_1_1controllers_1_1_router.html#a2372e685bbbd4522a9092a58578b2b65", null ],
    [ "checkRouteName", "class_ubiquity_1_1controllers_1_1_router.html#ab7b67abf3119d9e5480beee52e6f0371", null ],
    [ "cleanParam", "class_ubiquity_1_1controllers_1_1_router.html#a1f84be176878ae7a52b3019c6698a660", null ],
    [ "filterRoutes", "class_ubiquity_1_1controllers_1_1_router.html#a43c2e8b692245c1b8d5712cb7eaaf9d2", null ],
    [ "getAnnotations", "class_ubiquity_1_1controllers_1_1_router.html#ae682e43d526d437614255a0d1d39c3a5", null ],
    [ "getRoute", "class_ubiquity_1_1controllers_1_1_router.html#ae76a7d38673a1f6f4c1c00f3b112e822", null ],
    [ "getRouteByName", "class_ubiquity_1_1controllers_1_1_router.html#a97a6be67a3be78d02bbc1f47fdc1ee39", null ],
    [ "getRouteInfo", "class_ubiquity_1_1controllers_1_1_router.html#ad9f97b954a1d803aac975febd5b6381a", null ],
    [ "getRouteInfoByControllerAction", "class_ubiquity_1_1controllers_1_1_router.html#a5a634cd6a032e99fcd8d2be536648a2f", null ],
    [ "getRouteUrlParts", "class_ubiquity_1_1controllers_1_1_router.html#ad239727e844c3a4f2f1d5cb102b91dd6", null ],
    [ "path", "class_ubiquity_1_1controllers_1_1_router.html#a5e67f063c95cd06fdf6d461cb602f14e", null ],
    [ "setExpired", "class_ubiquity_1_1controllers_1_1_router.html#aa4209f435cd8c41a6cd5c16e9289f48d", null ],
    [ "slashPath", "class_ubiquity_1_1controllers_1_1_router.html#a2c50bb1b56ba15dfffdb87fc89be7313", null ],
    [ "start", "class_ubiquity_1_1controllers_1_1_router.html#a146085d0f3a9d17bdcd7f3d4081d8c0d", null ],
    [ "startRest", "class_ubiquity_1_1controllers_1_1_router.html#aec244f547413490d078f991a67ab7ad9", null ],
    [ "url", "class_ubiquity_1_1controllers_1_1_router.html#ac73e4a016facd771344cb62df08cdca4", null ],
    [ "$routes", "class_ubiquity_1_1controllers_1_1_router.html#a8f7eb04a54e0f0bfc0cedeb9899ce4a8", null ]
];