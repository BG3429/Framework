var class_ubiquity_1_1annotations_1_1_join_column_annotation =
[
    [ "$className", "class_ubiquity_1_1annotations_1_1_join_column_annotation.html#acd6a475a6eeb092f4eea3e19e502d67d", null ],
    [ "$referencedColumnName", "class_ubiquity_1_1annotations_1_1_join_column_annotation.html#aaae4d903761aaa6f9bcc0551d74c767f", null ]
];