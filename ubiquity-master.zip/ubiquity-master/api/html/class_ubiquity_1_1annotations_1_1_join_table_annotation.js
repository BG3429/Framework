var class_ubiquity_1_1annotations_1_1_join_table_annotation =
[
    [ "$inverseJoinColumns", "class_ubiquity_1_1annotations_1_1_join_table_annotation.html#ac73df77dff9138e8488d79faddc3b454", null ],
    [ "$joinColumns", "class_ubiquity_1_1annotations_1_1_join_table_annotation.html#a29ef4e5beb09d8a720180589e0e999a5", null ],
    [ "$name", "class_ubiquity_1_1annotations_1_1_join_table_annotation.html#ab2fc40d43824ea3e1ce5d86dee0d763b", null ]
];