<?php

namespace Ubiquity\annotations;

/**
 * Annotation ManyToOne
 * @author jc
 * @version 1.0.0.2
 */
class ManyToOneAnnotation extends BaseAnnotation {
}
