<?php

namespace Ubiquity\annotations;

/**
 * Annotation Table
 * @author jc
 * @version 1.0.0.1
 * @usage('class'=>true, 'inherited'=>true)
 */
class TableAnnotation extends BaseAnnotation {
	public $name;
}
