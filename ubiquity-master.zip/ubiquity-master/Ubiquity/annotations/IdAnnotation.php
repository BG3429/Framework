<?php

namespace Ubiquity\annotations;

/**
 * Annotation Id
 * @author jc
 * @version 1.0.0.1
 */
class IdAnnotation extends BaseAnnotation {
}
