<?php

namespace Ubiquity\annotations;

/**
 * Annotation Transient
 * @author jc
 * @version 1.0.0.2
 */
class TransientAnnotation extends BaseAnnotation {
}
