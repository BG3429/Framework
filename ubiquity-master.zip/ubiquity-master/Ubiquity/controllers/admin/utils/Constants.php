<?php

namespace Ubiquity\controllers\admin\utils;

class Constants {
	const REQUEST_METHODS=[ "get" => "GET","post" => "POST","put" => "PUT","patch" => "PATCH","delete" => "DELETE","head" => "HEAD","options" => "OPTIONS" ];
}
