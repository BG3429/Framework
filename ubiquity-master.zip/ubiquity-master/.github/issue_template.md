### Title (Put in field above)
Use the format: [part] Element Should Do X
i.e. [Router] Route requirement should allow to set an integer url parameter
[part] is one of [Views,Controllers,ORM,Router,REST,Config,Git,SEO,UbiquityMyAdmin]

### Steps

### Expected Result

### Actual Result

### Versions
Ubiquity framework x.y.z
Ubiquity devtools x.y.z
php x.y.z
