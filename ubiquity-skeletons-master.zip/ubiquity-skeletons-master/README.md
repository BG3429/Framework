# ubiquity-skeletons
## Projects options
| Project         | Options            |Description                                      |
| --------------- |:------------------:|:-----------------------------------------------:|
| base-a-semantic | -admin -q=semantic | Works with Semantic-ui, has the admin interface |

## Configuration
  - copy one of this projects to the root of your web server
  - After renaming the folder, edit the **.htaccess** and **app/config/config.php** files and change the **%base_url%** variable
